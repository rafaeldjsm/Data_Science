from sys import path
path.append('..\\packages')

import extra.iota
print(extra.iota.FunI())
